import type { Player, RoomState, GameSettings } from '../../src/types'
import { getQuizData } from './quizData'
import { getRuleDef, DEFAULT_SETTINGS } from './rules'

export const BUZZ_TIMEOUT_MS = 5000
export const ANSWER_TIMEOUT_MS = 8000
export const RESULT_SHOW_MS = 2500
const Q_DISPLAY_MS = 1500
const TYPEWRITER_SPEED_MS = 120

export function normalizeAnswer(input: string): string {
  let s = input.trim()
  // カタカナ→ひらがな
  s = s.replace(/[\u30A1-\u30F6]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0x60))
  // ひらがな・英数字以外を除去（長音符ーも除去）
  s = s.replace(/[^\u3041-\u309Fa-zA-Z0-9]/g, '')
  return s.toLowerCase()
}

function initPlayer(id: string, name: string, isHost: boolean, settings: GameSettings): Player {
  const rule = getRuleDef(settings.ruleId)
  return {
    id, name, score: 0, isHost,
    status: 'ACTIVE',
    ruleState: rule.initState(settings.ruleParams),
  }
}

export function createRoom(roomId: string, hostId: string, hostName: string): RoomState {
  const settings = { ...DEFAULT_SETTINGS }
  return {
    id: roomId,
    hostId,
    players: [initPlayer(hostId, hostName, true, settings)],
    phase: 'lobby',
    currentQuestionIndex: -1,
    currentQuestion: null,
    buzzedPlayerId: null,
    buzzedPlayerName: null,
    lastJudgement: null,
    lastAnswerPlayerId: null,
    timerEndsAt: null,
    totalQuestions: settings.questionCount,
    questionOrder: [],
    settings,
  }
}

export function updateSettings(state: RoomState, settings: GameSettings): RoomState {
  // settingsが変わったらruleStateを再初期化
  const rule = getRuleDef(settings.ruleId)
  const players = state.players.map(p => ({
    ...p,
    status: 'ACTIVE' as const,
    ruleState: rule.initState(settings.ruleParams),
  }))
  return { ...state, settings, players, totalQuestions: settings.questionCount }
}

export function addPlayer(state: RoomState, playerId: string, playerName: string): RoomState {
  if (state.players.find((p) => p.id === playerId)) return state
  return {
    ...state,
    players: [...state.players, initPlayer(playerId, playerName, false, state.settings)],
  }
}

export function removePlayer(state: RoomState, playerId: string): RoomState {
  return { ...state, players: state.players.filter((p) => p.id !== playerId) }
}

function shuffle(arr: number[]): number[] {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

export function advanceQuestion(state: RoomState, customQuestions?: import('../../src/types').Question[]): RoomState {
  const nextIndex = state.currentQuestionIndex + 1
  const sourceQuestions = customQuestions ?? getQuizData()
  const recentIds: Set<number> = new Set(state.recentQuestionIds ?? [])
  const pool = customQuestions
    ? sourceQuestions
    : sourceQuestions.filter(q => !recentIds.has(q.id))
  const available = pool.length > 0 ? pool : sourceQuestions
  const count = Math.min(state.settings.questionCount, available.length)

  // Fix①: questionOrderが一度確定したら絶対に再作成しない
  //   旧: state.questionOrder.length === count
  //       → countがrecentIdsの増加で縮小するたびにorderが短く再作成され早期終了していた
  //   新: state.questionOrder.length > 0 でゲーム中は常に既存orderを使用
  //
  // Fix②: orderにはavailable相対インデックスではなくsourceQuestionsの絶対インデックスを保存
  //       → availableがrecentIds変化やDB自動リロードで変わっても常に同じ問題を参照できる
  const order: number[] = state.questionOrder.length > 0
    ? state.questionOrder
    : shuffle(available.map(q => q.id)).slice(0, count)

  if (nextIndex >= order.length || checkGameEnd(state)) {
    return { ...state, phase: 'finished', currentQuestion: null, timerEndsAt: null, questionOrder: order }
  }

  // Fix②続き: availableではなくsourceQuestionsから直接取得
  const question = sourceQuestions.find(q => q.id === order[nextIndex])
  if (!question) {
    return { ...state, phase: 'finished', currentQuestion: null, timerEndsAt: null, questionOrder: order }
  }
  const typewriterMs = question.text.length * TYPEWRITER_SPEED_MS
  const prevRecent: number[] = state.recentQuestionIds ?? []
  const newRecent = question?.id
    ? [...prevRecent.filter((id: number) => id !== question.id), question.id].slice(-20)
    : prevRecent
  return {
    ...state,
    phase: 'question',
    currentQuestionIndex: nextIndex,
    currentQuestion: question,
    recentQuestionIds: newRecent,
    questionStartedAt: Date.now(),
    buzzedPlayerId: null,
    buzzedPlayerName: null,
    lastJudgement: null,
    lastAnswerPlayerId: null,
    timerEndsAt: Date.now() + Q_DISPLAY_MS + typewriterMs + BUZZ_TIMEOUT_MS,
    questionOrder: order,
    totalQuestions: order.length,
  }
}

export function skipQuestion(state: RoomState): RoomState {
  // Freeze/m◯n休: 休み中プレイヤーのrestを消化
  const rule = getRuleDef(state.settings.ruleId)
  let players = state.players
  if (rule.hasSkip && rule.onSkip) {
    players = state.players.map(p => {
      if (p.status !== 'ACTIVE') return p
      const result = rule.onSkip!(p.ruleState, state.settings.ruleParams)
      if (result) return { ...p, ruleState: { ...p.ruleState } }
      return p
    })
  }
  return {
    ...state,
    players,
    phase: 'result',
    lastJudgement: 'skip',
    buzzedPlayerId: null,
    buzzedPlayerName: null,
    lastAnswerPlayerId: null,
    timerEndsAt: Date.now() + RESULT_SHOW_MS,
  }
}

export function acceptBuzz(state: RoomState, playerId: string): RoomState {
  const player = state.players.find((p) => p.id === playerId)
  if (!player) return state
  return {
    ...state,
    phase: 'answering',
    buzzedPlayerId: playerId,
    buzzedPlayerName: player.name,
    timerEndsAt: Date.now() + ANSWER_TIMEOUT_MS,
  }
}

export function checkGameEnd(state: RoomState): boolean {
  const { winnerCount, loserCount } = state.settings
  const winners = state.players.filter(p => p.status === 'WIN').length
  const losers = state.players.filter(p => p.status === 'LOSE').length
  if (winnerCount > 0 && winners >= winnerCount) return true
  if (loserCount > 0 && losers >= loserCount) return true
  return false
}

export function applyAnswer(
  state: RoomState,
  playerId: string,
  rawAnswer: string
): { nextState: RoomState; correct: boolean } {
  if (state.buzzedPlayerId !== playerId) return { nextState: state, correct: false }

  const actual = normalizeAnswer(rawAnswer)
  // 空文字（未回答・タイムアウト）は問答無用で不正解とする
  const isBlank = actual === ''
  // answerフィールド（ひらがな）は必ず含める
  const base = state.currentQuestion?.answer ?? ''
  const arr = state.currentQuestion?.answers ?? []
  const acceptedAnswers = [...new Set([base, ...arr].filter(Boolean))]
  const correct = !isBlank && acceptedAnswers.some((a) => normalizeAnswer(a) === actual)

  const rule = getRuleDef(state.settings.ruleId)
  const players: Player[] = state.players.map((p) => {
    if (p.id !== playerId || p.status !== 'ACTIVE') return p
    const newRuleState = { ...p.ruleState }
    correct
      ? rule.onCorrect(newRuleState, state.settings.ruleParams)
      : rule.onWrong(newRuleState, state.settings.ruleParams)
    const newStatus = rule.getStatus(newRuleState, state.settings.ruleParams)
    // scoreはruleStateのscoreかcorrectカウントを反映
    const score = typeof newRuleState.score === 'number'
      ? newRuleState.score
      : typeof newRuleState.correct === 'number'
        ? newRuleState.correct as number
        : p.score
    return { ...p, ruleState: newRuleState, status: newStatus, score }
  })

  const nextState: RoomState = {
    ...state,
    phase: 'result',
    players,
    lastJudgement: correct ? 'correct' : 'incorrect',
    lastAnswerPlayerId: playerId,
    timerEndsAt: Date.now() + RESULT_SHOW_MS,
  }

  return { nextState, correct }
}

export function reassignHost(state: RoomState): RoomState {
  if (state.players.length === 0) return state
  const newHost = state.players[0]
  return {
    ...state,
    hostId: newHost.id,
    players: state.players.map((p) => ({ ...p, isHost: p.id === newHost.id })),
  }
}

export function disconnectPlayer(state: RoomState, playerId: string): RoomState {
  // ロビー中は待つ理由がないため即時退室のまま
  if (state.phase === 'lobby') return removePlayer(state, playerId)
  return {
    ...state,
    players: state.players.map((p) =>
      p.id === playerId && p.status === 'ACTIVE' ? { ...p, status: 'DISCONNECTED' as const } : p
    ),
  }
}

export function reconnectPlayer(state: RoomState, playerId: string): RoomState {
  return {
    ...state,
    players: state.players.map((p) =>
      p.id === playerId && p.status === 'DISCONNECTED' ? { ...p, status: 'ACTIVE' as const } : p
    ),
  }
}

export function finalizeDisconnect(state: RoomState, playerId: string): RoomState {
  return {
    ...state,
    players: state.players.map((p) =>
      p.id === playerId && p.status === 'DISCONNECTED' ? { ...p, status: 'LOSE' as const } : p
    ),
  }
}

